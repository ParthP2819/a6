﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PractThreeApi.Models.ViewModel
{
    public class OrderVM
    {
        public int PId { get; set; }
        public int PQuentity { get; set; }

    }
}
