﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PractThreeApi.Models.ViewModel
{
    public enum StatusType
    {
        Open,
        Draft,
        Shipped,
        Paid
    }
}
