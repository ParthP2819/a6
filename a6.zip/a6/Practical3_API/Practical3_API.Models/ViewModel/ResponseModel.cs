﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practical3_API.Models.ViewModel
{
    public class ResponseModel
    {
        public string Message { get; set; }
    }
}
