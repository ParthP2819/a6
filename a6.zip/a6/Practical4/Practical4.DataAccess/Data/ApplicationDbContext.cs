﻿using Microsoft.EntityFrameworkCore;
using Practical4.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practical4.DataAccess.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }
        public DbSet<OrderAddress> orderAddresses { get; set; }
        public DbSet<address> address  { get; set; }
       public DbSet<OrderDetails> orderitems { get; set; }
        
        
    }
}
