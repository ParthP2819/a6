﻿using Microsoft.EntityFrameworkCore;
using Practical4.DataAccess.Data;
using Practical4.DataAccess.Repository.IRepository;
using Practical4.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Practical4.DataAccess.Repository
{
    public class OrderRepository : IOrderRepository
    {
        private readonly ApplicationDbContext _db;
        private IQueryable<OrderDetails> dbSet;

        public OrderRepository(ApplicationDbContext db)
        {
            _db = db;
        }
        public void Update(OrderDetails obj)
        {
            _db.orderitems.Update(obj);
            _db.SaveChanges();
        }

        public OrderDetails GetFirstOrDefault(Expression<Func<OrderDetails, bool>> filter)
        {
            IQueryable<OrderDetails> query = dbSet;
            query = query.Where(filter);
            return query.FirstOrDefault();
        }
    }
}

