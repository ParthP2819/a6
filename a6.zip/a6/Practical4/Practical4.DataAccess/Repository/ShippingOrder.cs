﻿
using Practical4.DataAccess.Data;
using Practical4.DataAccess.Repository.IRepository;
using Practical4.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Practical4.DataAccess.Repository
{
    public class ShippingOrder: IShippingOrder
    {
        private readonly ApplicationDbContext _db;

        public ShippingOrder(ApplicationDbContext db)
        {
            _db = db;
        }
        public IEnumerable<address> GetAdd()
        {
            return _db.address.ToList();
        }

        public async Task<address> AddAddress(address address)
        {
            _db.address.Add(address);
            _db.SaveChanges();

            return address;
        }

        public void Save()
        {
            _db.SaveChanges();
        }
    }
}
