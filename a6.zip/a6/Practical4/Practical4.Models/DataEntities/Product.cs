﻿


using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Practical4.Models.DataEntities
{
    public class Product
    {
        [Key]

        public int productid { get; set; }
        [Required]
        public string name { get; set; }
        public string description { get; set; }
        public int price { get; set; }
        public int quantity { get; set; }

        public bool isactive { get; set; }
        public DateTime createdon { get; set; } = DateTime.Now;
        public DateTime modifiedon { get; set; } = DateTime.Now;

        //Foreign Key
        [Display(Name = "Category")]
        public int CategoryId { get; set; }
        [ForeignKey("CategoryId")]
        [ValidateNever]
        public Category Category { get; set; }
    }
}
