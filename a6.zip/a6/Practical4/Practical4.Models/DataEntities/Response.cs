﻿namespace Practical4.Models.DataEntities
{
    public class Response
    {
        public dynamic Data { get; set; } 
        public string? Status { get; set; }
        public string? Message { get; set; }
    }
}
