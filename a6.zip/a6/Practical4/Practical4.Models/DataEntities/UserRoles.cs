﻿namespace Practical4.Models.DataEntities
{
    public static class UserRoles
    {

        public const string Admin = "Admin";
        public const string User = "User";
    }
}
