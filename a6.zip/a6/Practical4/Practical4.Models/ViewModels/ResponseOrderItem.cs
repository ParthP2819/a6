﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practical4.Models.ViewModels
{
    public class ResponseOrderItem
    {
        public string Message { get; set; }
    }
}
