using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net;
using Practical4.DataAccess.Repository.IRepository;
using Practical4.DataAccess.Repository;
using Practical4.Models;
using Practical4.Models.DataEntities;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using static Practical4.Models.address;
using Practical4.Models.ViewModels;
using Newtonsoft.Json.Linq;
using System.Net.Http;
using System.Text;

namespace Practical4
{
   public class Function1
    {
        private readonly IShippingOrder _shippingOrder;
        private readonly IOrderRepository _orderRepository;
        public Function1(IShippingOrder shippingOrder, IOrderRepository orderRepository)
        {
            _shippingOrder = shippingOrder;
            _orderRepository = orderRepository;
        }

        [FunctionName("GetAddress")]
        public async Task<IActionResult> GetAddress(
            [HttpTrigger(AuthorizationLevel.Anonymous,"get","post",Route =null)]HttpRequest req,
            ILogger log)
        {
            var address = _shippingOrder.GetAdd();
            return new OkObjectResult(address);
        }

        [FunctionName("AddAddress")]
        public async Task<IActionResult> AddAddress(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            try
            {
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                address address = JsonConvert.DeserializeObject<address>(requestBody);
                var addedAddress = _shippingOrder.AddAddress(address);
                return new OkObjectResult(new Response { Data = addedAddress, Status = "Success" });
            }
            catch (Exception ex)
            {
                log.LogError(ex, "Error adding address to db");
                return new StatusCodeResult(500);
            }
        }

        [FunctionName("UpdateOrder")]
        public async Task<IActionResult> UpdateOrder(
          [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req,
          ILogger log)
        {
            var orderid = req.Query["orderid"];
            var status = req.Query["status"];
            var order = _orderRepository.GetFirstOrDefault(o => o.OrderId == int.Parse(orderid));
            if (order.IsActive != false)
            {
                if (order.StatusType >= (StatusType)int.Parse(status))
                {
                    return new StatusCodeResult(500);
                }
                else
                {
                    order.StatusType = (StatusType)int.Parse(status);
                    _orderRepository.Update(order);
                }
            }
            return new OkObjectResult(new Response { Data = order, Status = "Success" });
        }               
    }
}
     