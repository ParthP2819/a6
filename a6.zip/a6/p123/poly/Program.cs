﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace poly
{
    // Method Overrding
    internal class Program
    {
        class animal
        {
            public void Eat()   
            {
                Console.WriteLine("animal is eating");
            }
        }
        class dog: animal
        {
            public static void Main(string[] args)
            {
                dog tommy= new dog();
                tommy.Eat();    
            }
        }
        
    }
    // // Method OverLoading
    //internal class Program
    //{
    //    void SUM(int a, int b) 
    //    {
    //        Console.WriteLine(a + b);
    //    }
    //    void SUM(float a,float b) 
    //    {
    //        Console.WriteLine(a+b);
    //    }
    //    static void Main(string[] args)
    //    {
    //        Program obj = new Program();
    //    }
    //}
}
